<?php if( is_active_sidebar( 'aprenda-wp-sidebar-shop' ) ): ?>
	<?php dynamic_sidebar( 'aprenda-wp-sidebar-shop' ); ?>
<?php endif;