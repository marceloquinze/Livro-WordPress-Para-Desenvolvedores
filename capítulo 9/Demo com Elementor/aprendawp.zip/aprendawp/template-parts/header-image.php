<?php
/**
 * Template part for displaying the site custom header
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package AprendaWP
 */

?>
<img class="img-fluid" src="<?php header_image(); ?>" height="<?php echo esc_attr( get_custom_header()->height ); ?>" width="<?php echo esc_attr( get_custom_header()->width ); ?>" alt="" />